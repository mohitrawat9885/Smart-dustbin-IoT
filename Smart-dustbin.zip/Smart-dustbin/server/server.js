const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const path = require("path");

const app = express();
const port = 5000;

// Create an HTTP server
const server = http.createServer(app);

// Initialize Socket.IO with CORS configuration
const io = new Server(server, {
  cors: {
    origin: "*", // You can restrict this to your specific client URL if needed
    methods: ["GET", "POST"],
  },
});

// Middleware to parse JSON bodies
app.use(express.json());

// Use CORS middleware
app.use(cors());

// Serve static files from the React build directory
app.use(express.static(path.join(__dirname, "smart-dustbin")));

// Serve the index.html file for any unknown routes (for React Router)
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "build", "index.html"));
});

// Handle the POST request and emit data to the client
app.post("/smart-dustbin", (req, res) => {
  console.log("Received POST request:", req.body);

  // Emit the data to all connected clients
  io.emit("waste-percentage", { percentage: req.body.dustbinFull });
  console.log("Emitted waste-percentage:", req.body.dustbinFull);

  res.send("ok");
});

// Handle socket connections
io.on("connection", (socket) => {
  console.log("A user connected");

  // Handle disconnection
  socket.on("disconnect", () => {
    console.log("User disconnected");
  });
});

// Start the server
server.listen(port, () => {
  console.log(`Server is running on http://192.168.66.14:${port}`);
});
