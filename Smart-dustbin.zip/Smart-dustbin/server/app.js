import express, { json } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import globalErrorHandler from "./exception/errorController.js";
import instituteRouter from "./routes/instituteRoutes.js";
import userRouter from "./routes/userRoutes.js";
import courseRouter from "./routes/courseRouters.js";
import adminRouter from "./routes/adminRouters.js";
import bookCounsellingRouters from "./routes/bookCounsellingRouters.js";
import AppError from "./exception/appError.js";
// import { createSendToken } from "./authentication/authController.js";
const app = express();

const allowedOrigins = ["https://flcs.in", "https://www.flcs.in"];

const corsOptions = {
  origin: (origin, callback) => {
    // Check if the incoming origin is in the list of allowed origins
    if (allowedOrigins.indexOf(origin) !== -1 || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true,
  optionSuccessStatus: 200,
};

// const corsOptions = {
//   origin: "https://flcs.in",
//   credentials: true, //access-control-allow-credentials:true
//   optionSuccessStatus: 200,
// };

app.use(cors(corsOptions));

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "https://flcs.in"); // No trailing slash
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, OPTIONS, PUT, PATCH, DELETE"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "X-Requested-With,content-type"
  );
  res.setHeader("Access-Control-Allow-Credentials", true);
  next();
});

app.use(cookieParser());
app.enable("trust proxy");
app.use(json());

// app.options("*", cors());

app.use("/flcs_api/institute", instituteRouter);
app.use("/flcs_api/user", userRouter);
app.use("/flcs_api/course", courseRouter);
app.use("/flcs_api/admin", adminRouter);
app.use("/flcs_api/book-counselling", bookCounsellingRouters);

app.all("*", (req, res, next) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
});

app.use(globalErrorHandler);
export default app;
