// src/components/WastePercentage.js
import React, { useEffect, useState } from "react";
import socket from "../socket";

const WastePercentage = () => {
  const [percentage, setPercentage] = useState(0);

  useEffect(() => {
    console.log("Component mounted, setting up socket listeners");

    // Listen for real-time waste percentage data
    socket.on("waste-percentage", (data) => {
      console.log("Received waste-percentage:", data);
      setPercentage(data.percentage);
    });

    // Clean up the effect
    return () => {
      console.log("Component unmounted, cleaning up socket listeners");
      socket.off("waste-percentage");
    };
  }, []);

  return (
    <div className="waste-container">
      <h1>Smart Dustbin</h1>
      <div className="waste-display">
        <h2>Waste Percentage: {percentage}%</h2>
      </div>
    </div>
  );
};

export default WastePercentage;
