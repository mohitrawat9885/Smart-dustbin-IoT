// src/socket.js
import { io } from "socket.io-client";

const SOCKET_URL = "/";
const socket = io(SOCKET_URL);

export default socket;
