import express, { json } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import globalErrorHandler from "./exception/errorController.js";
import instituteRouter from "./routes/instituteRoutes.js";
import userRouter from "./routes/userRoutes.js";
import courseRouter from "./routes/courseRouters.js";
import employeeRouters from "./routes/employeeRouters.js";
import bookCounsellingRouter from "./routes/bookCounsellingRouters.js";
import AppError from "./exception/appError.js";

const app = express();

const allowedOrigins =
  process.env.NODE_ENV === "production"
    ? ["https://flcs.in", "https://www.flcs.in"]
    : ["http://192.168.32.14:3000", "http://localhost:3000"];

const corsOptions = {
  origin: (origin, callback) => {
    if (allowedOrigins.includes(origin) || !origin) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true,
  optionsSuccessStatus: 200,
};

app.use(cors(corsOptions));
app.use(helmet());
app.use(morgan("dev")); // Logging HTTP requests
app.use(cookieParser());
app.enable("trust proxy");
app.use(json());

// Rate limiting
const limiter = rateLimit({
  max: 100, // Limit each IP to 100 requests per window (here, per hour)
  windowMs: 60 * 60 * 1000, // 1 hour
  message: "Too many requests from this IP, please try again in an hour!",
});
app.use(limiter);

app.use("/flcs_api/institute", instituteRouter);
app.use("/flcs_api/user", userRouter);
app.use("/flcs_api/course", courseRouter);
app.use("/flcs_api/employee", employeeRouters);
app.use("/flcs_api/book-counselling", bookCounsellingRouter);

app.all("*", (req, res, next) => {
  next(new AppError(`Can't find ${req.originalUrl} on this server!`, 404));
});

app.use(globalErrorHandler);

export default app;
