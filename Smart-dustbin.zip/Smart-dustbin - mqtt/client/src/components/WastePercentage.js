import React, { useEffect, useState } from "react";
import mqttClient from "../mqttClient";

const WastePercentage = () => {
  const [percentage, setPercentage] = useState("0");

  useEffect(() => {
    console.log("Component mounted, setting up MQTT listeners");

    // Subscribe to the MQTT topic
    mqttClient.subscribe("smart-dustbin/waste-percentage");

    // Handle incoming messages
    mqttClient.on("message", (topic, message) => {
      if (topic === "smart-dustbin/waste-percentage") {
        const data = JSON.parse(message.toString());
        console.log("Received waste-percentage:", data.dustbinFull);
        setPercentage(data.dustbinFull);
      }
    });

    // Clean up the effect
    return () => {
      console.log("Component unmounted, cleaning up MQTT listeners");
      mqttClient.unsubscribe("smart-dustbin/waste-percentage");
    };
  }, []);

  return (
    <div className="waste-container">
      <h1>Smart Dustbin</h1>
      <div className="waste-display">
        <h2>Waste Percentage: {percentage}%</h2>
      </div>
    </div>
  );
};

export default WastePercentage;
