// src/App.js
import React from "react";
import WastePercentage from "./components/WastePercentage";
import "./App.css";

function App() {
  return (
    <div className="App">
      <WastePercentage />
    </div>
  );
}

export default App;
