import mqtt from "mqtt";

const MQTT_BROKER_URL = "ws://flcs.in:8888"; // You can replace with your specific broker URL
const client = mqtt.connect(MQTT_BROKER_URL);

client.on("connect", () => {
  console.log("Connected to MQTT broker");
});

export default client;
