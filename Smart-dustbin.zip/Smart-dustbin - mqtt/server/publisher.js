const mqtt = require("mqtt");
const client = mqtt.connect("ws://flcs.in:8888");

client.on("connect", () => {
  console.log("Publisher connected to MQTT broker");
  client.publish(
    "smart-dustbin/waste-percentage",
    '{"dustbinFull": "' + "100" + '"}'
  );
  client.end();
});
