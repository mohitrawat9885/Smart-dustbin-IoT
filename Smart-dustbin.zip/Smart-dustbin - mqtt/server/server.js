const Email = require("./Email");
const aedes = require("aedes")();
const http = require("http");
const ws = require("ws");
const net = require("net");
const express = require("express");
const path = require("path");

const app = express();
const mqttPort = 1883;
const wsPort = 8888;
const httpPort = 9000; // Port for serving the React app

// TCP server for MQTT
const mqttServer = net.createServer(aedes.handle);

mqttServer.listen(mqttPort, () => {
  console.log(`Aedes MQTT broker running on port ${mqttPort}`);
});

// HTTP server for WebSocket connections
const httpServer = http.createServer();
const wsServer = new ws.Server({ server: httpServer });

wsServer.on("connection", (socket) => {
  const stream = ws.createWebSocketStream(socket);
  aedes.handle(stream);
});

httpServer.listen(wsPort, () => {
  console.log(`Aedes MQTT broker (WebSocket) running on port ${wsPort}`);
});

// Middleware to parse JSON bodies
app.use(express.json());

// Use CORS middleware
app.use(require("cors")());

// Serve static files from the React build directory
app.use(express.static(path.join(__dirname, "build")));

// Serve the index.html file for any unknown routes (for React Router)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "build", "index.html"));
});

// Start the HTTP server for serving the React app
app.listen(httpPort, () => {
  console.log(`HTTP server running and serving React app on port ${httpPort}`);
});

aedes.on("client", (client) => {
  console.log(`Client connected: ${client.id}`);
});

aedes.on("publish", (packet, client) => {
  if (client) {
    const dustbin = JSON.parse(packet.payload.toString());
    console.log(`Message from ${client.id}: ${packet.payload.toString()}`);
    console.log(dustbin.dustbinFull);
    if (dustbin.dustbinFull === "100") {
      Email("mohitrawat9885@gmail.com");
    }
  }
});
