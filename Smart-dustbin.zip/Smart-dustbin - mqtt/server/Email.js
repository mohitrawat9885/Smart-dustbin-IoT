const nodemailer = require("nodemailer");
const smtpConfig = {
  host: "smtpout.secureserver.net",
  port: 465,
  secure: true, // true for port 465, false for 587
  auth: {
    user: "services@flcs.in",
    pass: "flcsservices@2024",
  },
};

const transporter = nodemailer.createTransport(smtpConfig);

const sendEmail = async (toEmail) => {
  const mailOptions = {
    from: "services@flcs.in",
    to: toEmail,
    subject: "Your Dustbin is Full.",
    text: `Please Make it Empty.`,
  };

  try {
    let info = await transporter.sendMail(mailOptions);
    console.log("Email sent: %s", info.messageId);
  } catch (error) {
    console.error("Error sending ", error);
    throw error;
  }
};

module.exports = sendEmail;
