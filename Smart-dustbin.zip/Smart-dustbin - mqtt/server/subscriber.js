const mqtt = require("mqtt");
const client = mqtt.connect("mqtt://localhost:1883");

client.on("connect", () => {
  console.log("Subscriber connected to MQTT broker");
  client.subscribe("smart-dustbin/waste-percentage", (err) => {
    if (!err) {
      console.log("Subscribed to test/topic");
    }
  });
});

client.on("message", (topic, message) => {
  console.log(`Received message: ${message.toString()}`);
});
