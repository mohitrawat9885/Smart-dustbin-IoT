import paho.mqtt.client as mqtt

# MQTT settings
MQTT_BROKER = 'localhost'
MQTT_PORT = 1883
MQTT_TOPIC = 'test/topic'

# Create an MQTT client instance
client = mqtt.Client()

# Define the on_connect event handler
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    client.subscribe(MQTT_TOPIC)

# Define the on_message event handler
def on_message(client, userdata, msg):
    print(f"Received message: {msg.topic} {msg.payload.decode()}")

# Set the event handlers
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker
client.connect(MQTT_BROKER, MQTT_PORT, 60)

# Start the MQTT client loop in a separate thread
client.loop_start()

# Publish a test message
client.publish(MQTT_TOPIC, "Hello MQTT from client test script!")

# Keep the script running to receive messages
import time
while True:
    time.sleep(1)
