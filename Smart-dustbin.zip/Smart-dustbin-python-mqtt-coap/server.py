from flask import Flask, request, jsonify
import paho.mqtt.client as mqtt
import asyncio
from aiocoap import *

app = Flask(__name__)

# MQTT settings
MQTT_BROKER = 'flcs.in'
MQTT_PORT = 1883
MQTT_TOPIC = 'smart-dustbin/waste-percentage'

# Create an MQTT client instance
mqtt_client = mqtt.Client()

# Define the on_connect event handler
def on_connect(client, userdata, flags, rc):
    print(f"Connected with result code {rc}")
    client.subscribe(MQTT_TOPIC)

# Define the on_message event handler
def on_message(client, userdata, msg):
    print(f"Received message: {msg.topic} {msg.payload.decode()}")
    asyncio.run(forward_to_coap(msg.payload.decode()))

# Set the event handlers
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

# Connect to the MQTT broker
mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)

# Start the MQTT client in a separate thread
mqtt_client.loop_start()

async def forward_to_coap(data):
    context = await Context.create_client_context()
    request = Message(code=PUT, payload=data.encode('utf8'))
    request.set_request_uri('coap://localhost/resource')

    try:
        response = await context.request(request).response
        print('Result: %s\n%r' % (response.code, response.payload))
    except Exception as e:
        print('Failed to fetch resource:')
        print(e)

@app.route('/')
def index():
    return "MQTT to CoAP Server is running"

@app.route('/publish', methods=['POST'])
def publish():
    data = request.json
    topic = data.get('topic', MQTT_TOPIC)
    message = data.get('message', '')
    mqtt_client.publish(topic, message)
    return jsonify({'status': 'Message published'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
